【無料あり】杖っぽい箒　オリジナル3Dモデル【VRChat想定】
制作者：S-Thurk

VRChat想定の自作箒です Δ7652

本モデルは3Dモデルデータです。
商用利用や改変が可能で、ゲームや配信等にも
使うことができます。

ハロウィン向けに自作しました
シェイプキーで先端の球と杖形状を変形させることができます

CADモデリング出力のΔ125468の方を支援版で置いておきます
Blenderのデシメートで無理やりポリゴン削減させたので弄りたい人向け

・利用規約

改変：可
商用利用：可
再配布、本データを含めた販売：不可
アバターやワールドへの使用：可
ぺデスタルへの使用：可
本モデルデータの使用による損失・損害等は一切責任を負いかねます。


・Contents
st-houki.unitypackage
st-houki_Low.fbx
(st-houki_High125468.fbx)
houki-base.png
ball.png
houki-baseUV.png
readme.txt

・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・・
Original 3D model broom
Producer: S-Thurk

This model is 3D model data.
It can be used for commercial purposes and modified, and can be used for games and distribution.
You can use it.


·Terms of service

Modification: Yes
Commercial use: Yes
Redistribution, sales including this data: No
Use for avatar or world: Yes
Use for pedestal: Yes
We are not responsible for any loss or damage caused by using this model data.
